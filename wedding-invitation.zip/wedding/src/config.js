// ВСЁ, что нужно менять, находится в этом файле.

// Заглушка-фото (SVG). Чтобы поставить своё: положите файл в public/photos/
// и впишите src: photo("1.jpg")
const BASE = import.meta.env.BASE_URL;
export const photo = (name) => `${BASE}photos/${name}`;

const ph = (label, a, b) =>
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 600 800'>
      <defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='${a}'/><stop offset='1' stop-color='${b}'/></linearGradient></defs>
      <rect width='600' height='800' fill='url(#g)'/>
      <circle cx='430' cy='250' r='150' fill='#fff' opacity='.12'/>
      <circle cx='160' cy='620' r='210' fill='#000' opacity='.08'/>
      <text x='300' y='410' font-family='Georgia,serif' font-size='34' font-style='italic' text-anchor='middle' fill='#fff' opacity='.75'>${label}</text>
    </svg>`
  );

export const wedding = {
  names: ["Анна", "Михаил"],
  dateISO: "2026-12-04T16:00:00+05:00", // Челябинск, UTC+5
  dateText: "4 декабря 2026",
  weekday: "пятница",
  time: "16:00",
  venue: "Avenue",
  place: "Челябинск, Кировка",
  mapUrl: "https://yandex.ru/maps/?text=Avenue%20Кировка%20Челябинск",
  telegram: "your_username", // ник в Telegram без @, куда придут ответы гостей
  lead: "Мы женимся и хотим разделить этот день с вами",

  photos: [
    { src: ph("фото 1", "#D9BC93", "#8A6141"), alt: "Фото 1" },
    { src: ph("фото 2", "#EAD7B7", "#A97F5C"), alt: "Фото 2" },
    { src: ph("фото 3", "#C4A07A", "#45291C"), alt: "Фото 3" },
    { src: ph("фото 4", "#F6EBD9", "#C4A07A"), alt: "Фото 4" },
    { src: ph("фото 5", "#A97F5C", "#2B1A11"), alt: "Фото 5" },
  ],

  schedule: [
    { t: "16:00", text: "Сбор гостей" },
    { t: "16:30", text: "Церемония" },
    { t: "17:30", text: "Банкет" },
    { t: "22:00", text: "Финал вечера" },
  ],

  // 8 цветов: от сливочного до шоколадного. dark: true — светлый текст на ткани
  palette: [
    { name: "Сливки", hex: "#F6EBD9" },
    { name: "Ваниль", hex: "#EAD7B7" },
    { name: "Овсянка", hex: "#D9BC93" },
    { name: "Карамель", hex: "#C4A07A" },
    { name: "Капучино", hex: "#A97F5C", dark: true },
    { name: "Корица", hex: "#8A6141", dark: true },
    { name: "Какао", hex: "#6A4630", dark: true },
    { name: "Шоколад", hex: "#45291C", dark: true },
  ],
};
